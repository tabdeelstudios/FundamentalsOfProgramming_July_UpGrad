package com.company.CollectionFrameworkInJava;

import java.util.*;

public class Main {

    public static void main(String[] args) {

			HashMap<Integer, String> studentMap = new HashMap<Integer, String>();

			studentMap.put(1, "John");
			studentMap.put(12, "Jane");
			studentMap.put(300, "Natasha");

			studentMap.remove(12);

			System.out.println(studentMap);
		}
}











/*
ArrayList Implementation

package com.company.CollectionFrameworkInJava;

import java.util.*;

public class Main {

    public static void main(String[] args) {
//	    ArrayList<String> paintingCompetitionParticipants = new ArrayList<String>();
//	    paintingCompetitionParticipants.add("John");
//	    paintingCompetitionParticipants.add("Jane");
//	    paintingCompetitionParticipants.add("Rick");
//	    paintingCompetitionParticipants.add("Natasha");
//	    paintingCompetitionParticipants.set(3, "Nicole");

		ArrayList<Integer> rollNumbers = new ArrayList<Integer>();
		rollNumbers.add(50);
		rollNumbers.add(20);
		rollNumbers.add(1);
		rollNumbers.add(-10);
		rollNumbers.remove(3);

//		System.out.println(rollNumbers.get(3));


		Collections.sort(rollNumbers);

		for (int student:rollNumbers) {

		}

//		System.out.println(rollNumbers.get(3));

//	    Iterator<String> loop = paintingCompetitionParticipants.iterator();
//	    int position = 0;
//	    while(loop.hasNext())
//		{
//			position++;
//			System.out.println(loop.next()+"_"+position);
//		}

//	    System.out.println(paintingCompetitionParticipants);

    }
}

 */