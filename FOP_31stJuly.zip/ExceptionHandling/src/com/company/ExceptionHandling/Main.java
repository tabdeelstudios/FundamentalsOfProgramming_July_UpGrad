package com.company.ExceptionHandling;

public class Main {

    public static void main(String[] args){

    }
}


/*

Arithmetic Exception

try{
            int num = 10/0;
        }catch(ArithmeticException e){
            System.out.println(e);
            System.out.println("This operation is invalid.");
        }
 */

/*
Null Pointer Exception

String data = null;
        try{
            System.out.println(data.length());
        }catch(NullPointerException e){
            System.out.println(e);
            System.out.println("This operation is invalid.");
        }
 */

/*
ArrayIndexOutOfBounds Exception

   try {
            int array[] = new int[10];
            System.out.println(array[10]);
        }catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
 */

/*
Finally block

String data = null;
        try{
            System.out.println(data.length());
        }catch(NullPointerException e){
            System.out.println(e);
            System.out.println("This operation is invalid.");
        }
        finally {
            System.out.println("This is finally block");
        }
 */

/*
Throws
package com.company.ExceptionHandling;

public class Main {

    public static void main(String[] args) throws ArithmeticException{

        int num = 10/0;
        System.out.println(num);
    }
}
 */