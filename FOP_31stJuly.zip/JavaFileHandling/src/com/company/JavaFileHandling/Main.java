package com.company.JavaFileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        String currentDirectory = "C:\\Users\\91822\\Desktop";
        FileWriter myFile = new FileWriter(currentDirectory + "newFile.txt");
        myFile.write("This is the first file I created with Java.");
        myFile.close();
        System.out.println("Data writing successful!");

    }
}


/*

//Reading properties of a file
import java.io.File;
File myFile = new File("C:\\Users\\91822\\Desktop\\myFile.txt");

if(myFile.exists())
        {
            System.out.println("The name of the file is : "+myFile.getName());
            System.out.println("The path of the file is : "+myFile.getAbsolutePath());
            System.out.println("The size of the file is : "+myFile.length());
            System.out.println("The file supports reading : "+ myFile.canRead());
            System.out.println("The file supports writing : "+ myFile.canWrite());
        }
        else
        {
            System.out.println("The file doesn't exist!");
        }

*/

/*

//Writing data to a file

import java.io.FileWriter;

String currentDirectory = "C:\\Users\\91822\\Desktop";
        FileWriter myFile = new FileWriter(currentDirectory + "newFile.txt");
        myFile.write("This is the first file I created with Java.");
        myFile.close();
        System.out.println("Data writing successful!");

*/

/*

//Reading content from a file
import java.io.File;
import java.util.Scanner;
File readFile = new File("C:\\Users\\91822\\Desktop\\newFile.txt");
        Scanner input = new Scanner(readFile);
        String fileContent = "";
        System.out.println("The file contains : \n");
        while(input.hasNextLine()) {
            fileContent = input.nextLine();
            System.out.println(fileContent);
        }
        input.close();
 */

/*
//Deleting a file
import java.io.File;
File myFile = new File("C:\\Users\\91822\\Desktop\\myFile.gwhdf");
        if(myFile.delete())
        {
            System.out.println("File deleted successfully!");
        }
        else
        {
            System.out.println("Something went wrong.");
        }
 */

/*
//Changing file permissions
 String currentDirectory = "C:\\Users\\91822\\Desktop";
        File myFile = new File(currentDirectory + "newFile.txt");

        //set file permissions
        myFile.setReadable(true);
        myFile.setWritable(false);
        myFile.setExecutable(true);

        System.out.println(myFile.canRead());
 */