package com.company.HandlingFIlesInJava;

public class Main {

    public static void main(String[] args) {

    }
}

/*

//Creating a new file

package com.company.HandlingFIlesInJava;

import java.io.File;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
	    File myFile = new File("C:\\Users\\91822\\Desktop\\newFile.txt");
	    if(myFile.createNewFile())
        {
            System.out.println("File created successfully!");
        }
	    else
        {
            System.out.println("Something went wrong!");
        }
    }
}

 */

/*
//Getting file information
package com.company.HandlingFIlesInJava;

import java.io.File;
public class Main {

    public static void main(String[] args) {
        File myFile = new File("C:\\Users\\91822\\Desktop\\newFile.txt");
        if(myFile.exists())
        {
            System.out.println("The file exists. Here are the details : ");
            System.out.println("File Size : "+myFile.length()+" bytes");
            System.out.println("File Name : "+myFile.getName());
            System.out.println("File Path : "+myFile.getAbsolutePath());
            System.out.println("File is Read Only : "+myFile.canRead());
            System.out.println("File is Write Only : "+myFile.canWrite());
            System.out.println("File is Executable Only : "+myFile.canExecute());
        }
        else{
            System.out.println("File not found!");
        }
    }
}


 */

/*
Writing content to a file

package com.company.HandlingFIlesInJava;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        FileWriter newFile = new FileWriter("C:\\Users\\91822\\Desktop\\newFile.txt", true);
        newFile.write(". This is brand new content!");
        System.out.println("Writing successful!");
        newFile.close();
    }
}

 */

/*

Reading data from a file

package com.company.HandlingFIlesInJava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        File myFile = new File("C:\\Users\\91822\\Desktop\\newFile.txt");
        Scanner input = new Scanner(myFile);
        String content = "";
        System.out.println("The file contains : \n");
        while(input.hasNextLine())
        {
            content = input.nextLine();
            System.out.println(content);
        }

    }
}
 */

/*

Deleting a file

package com.company.HandlingFIlesInJava;

import java.io.File;
public class Main {

    public static void main(String[] args) {
        File myFile = new File("C:\\Users\\91822\\Desktop\\newFile.pdf");
        if(myFile.exists())
        {
            if(myFile.delete())
            {
                System.out.println("Deletion successful!");
            }
            else {
                System.out.println("Something went wrong during deletion!");
            }
        }
        else
        {
            System.out.println("File not found");
        }

    }
}
 */
