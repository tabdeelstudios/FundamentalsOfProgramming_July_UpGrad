package com.company.JavaExceptions;

public class Main {

    public static void main(String[] args) {

    }
}


/*
Arithmetic Exception

package com.company.JavaExceptions;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n1, n2;
        n1 = input.nextInt();
        n2 = input.nextInt();
        try
        {
            System.out.println(n1/n2);
        }catch (ArithmeticException e)
        {
            System.out.println(e);
        }
        finally
        {
            System.out.println("Continue with the code..");
        }

    }
}


 */


/*

Null Pointer Exception

package com.company.JavaExceptions;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String name = null;
        try{
            System.out.println(name.length());
        }catch(NullPointerException e)
        {
            System.out.println(e);
        }
        finally {
            System.out.println("Continue with the code..");
        }
    }
}

 */

/*

Array Index Out Of Bounds Exception

package com.company.JavaExceptions;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int[] array = new int[10];
        System.out.println("Which element do you want to access?");
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        try{
            System.out.println(array[n]);
        }catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println(e);
        }
        finally {
            System.out.println("Continue with the code..");
        }

    }
}

 */

/*

Creating a custom exception

package com.company.JavaExceptions;

import java.util.Scanner;

class InvalidRangeException extends Exception{
    InvalidRangeException(String s){
        super(s);
    }
}

public class Main {

    static void checkInput(int choice) throws InvalidRangeException{
        if(choice>=1 && choice<=4)
        {
            System.out.println("Valid");
        }
        else
        {
            throw new InvalidRangeException("Please choose between 1 and 4.");
        }
    }

    public static void main(String[] args) {
        System.out.println("Pick one : 1. Pizze\n2. Pasta\n3. Noodles\n4. Rice Bowl");
        Scanner input = new Scanner(System.in);
        int choice = input.nextInt();
        try{
            checkInput(choice);
            System.out.println("The choice is : "+choice);
        }catch(Exception e)
        {
            System.out.println(e);
        }
        finally {
            System.out.println("Taking you back to the menu...");
        }

    }
}
 */